#####################################################
# Student
#       Name: <**YOUR NAME HERE**>
#       ID: <**YOUR ID HERE**>
#####################################################

#####################################################
# A class to define a 4x4 sudoko game
# Examples: http://1sudoku.com/play/sudoku-kids-free/sudoku-4x4/ 
#####################################################


class Problem:
    def __init__(self):
        # Define initial state + any additional class variables that you need
        # variable name: initState

        #<*** YOUR CODE HERE ***>



    # calculate the legal actions that could be taken at a given state
    # function name: actions
    # input: a state
    # output: list of actions
    def actions(self,state):

        #<*** YOUR CODE HERE ***>



    # calculate the next state resulting by taking a specific action
    # function name: result
    # input: a state and an action
    # output: a state
    def result(self,state,action) :

        #<*** YOUR CODE HERE ***>



    # check whether the goal is satisfied/reached in a given state
    # function name: goalTest
    # input: a state
    # output: a Boolean value
    def goalTest(self,state):

        #<*** YOUR CODE HERE ***>



    # calculate the step cost
    # function name: stepCost
    # input: a state and an action
    # output: a positive value
    def stepCost(self,state,action): 

        #<*** YOUR CODE HERE ***>



    # calculate the path cost
    # function name: pathCost
    # input: a state and a list of action
    # output: a non-negative value
    def pathCost(self,state,actionList):

        #<*** YOUR CODE HERE ***>







# ########################################################
# ########################################################
# Main Function (UNCOMMENT ONLY FOR TESTING PURPOSES ONLY)
# ########################################################
# ########################################################

if __name__ == '__main__':
    problem = Problem()

    # Test your code by calling the methods of the object "problem"
    # and check whether they produce the expected results.
    # For instance, "problem.actions(state1)" should produce the
    # list of actions that are allowed to be taken from "state1"

    #<*** YOUR CODE HERE ***>
