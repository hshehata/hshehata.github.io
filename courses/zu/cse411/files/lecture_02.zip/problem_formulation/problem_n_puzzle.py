# useful stuff: enum datatype & many classes: Window, FifoQueue,
#               LifoQueue, PriorityQueue, Set
from utilities import *

######################################################################
# A class to define the n-puzzle (e.g., 8-puzzle) problem
# Public variables/functions: initState, actions, results, goalTest,
#                             stepCost, pathCost,
#                             drawSolution, heuristic
######################################################################
class Problem:
    def __init__(self):
        #Basic:
        #######
##        self.initState = ((3,0,2),\
##                          (7,6,4),\
##                          (8,5,1))

        self.initState = ((1,0,2),\
                          (4,5,3),\
                          (6,7,8))
        #Problem-specific:
        ##################
        self.actionType = enum("left","right","up","down")

    def getBlankLoc(self,state) :
        for r in range(len(state)):
            for c in range(len(state)):
                if state[r][c]==0:
                    return (r,c)
        raise RuntimeError("Can't find a BLANK in a state: " + str(state))

    # calculate the legal actions that could be taken at a given state
    def actions(self,state) :
        legalActions = []
        nRow = nCol = len(state)
        (row,col) = self.getBlankLoc(state)
        if row!=0:
            legalActions += [self.actionType.up]
        if row!=(nRow-1):
            legalActions += [self.actionType.down]
        if col!=0:
            legalActions += [self.actionType.left]
        if col!=(nCol-1):
            legalActions += [self.actionType.right]
        return legalActions

    # calculate the next state resulting by taking a specific action
    def result(self,state,action) :
        (row,col) = self.getBlankLoc(state)
        state = list(list(x) for x in state)
        if action==self.actionType.left:
            state[row][col] = state[row][col-1]
            state[row][col-1] = 0
        if action==self.actionType.right:
            state[row][col] = state[row][col+1]
            state[row][col+1] = 0
        if action==self.actionType.up:
            state[row][col] = state[row-1][col]
            state[row-1][col] = 0
        if action==self.actionType.down:
            state[row][col] = state[row+1][col]
            state[row+1][col] = 0
        return tuple(tuple(x) for x in state)

    # check whether the goal is satisfied/reached in a given state
    def goalTest(self,state):
        for r in range(len(state)):
            for c in range(len(state)):
                if state[r][c]!=r*len(state)+c:
                    return False
        return True

    # calculate the step cost
    def stepCost(self,state,action): 
        return 1

    # calculate the path cost
    def pathCost(self,state,actionList):
        if actionList==[]: return 0
        return self.stepCost(state,actionList[0]) + \
            pathCost(self.result(state,actionList[0]),actionList[1:])

    # draw the solution and visualize the search state space
    def drawSolution(self,title,solution,stateMap={}):
        for a in solution:
            if a==self.actionType.left:
                print('left')
            elif a==self.actionType.right:
                print('right')
            elif a==self.actionType.down:
                print('down')
            elif a==self.actionType.up:
                print('up')

    # A heuristic function to estimate how far the goal is
    def heuristic(self,state):
        nRow = nCol = len(state)
        # The Manhattan distance heuristic
        manhattanHeuristic = 0
        for r in range(nRow):
            for c in range(nCol):
                if state[r][c]!=0:
                    manhattanHeuristic += abs(int(state[r][c]/nRow) - r) +\
                                          abs(state[r][c]%nRow - c)
        return manhattanHeuristic


# ########################################################
# ########################################################
# Main Function (FOR TESTING PURPOSES ONLY)
# ########################################################
# ########################################################
if __name__ == '__main__':
    p = Problem()

