print('Hello, world!')

