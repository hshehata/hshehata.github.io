print('Goodbye, world!')

