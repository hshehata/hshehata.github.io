text = input('XXXX')
number = XXXX
print(2.5 + number)
