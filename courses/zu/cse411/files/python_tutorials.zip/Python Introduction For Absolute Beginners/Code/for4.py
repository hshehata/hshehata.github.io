for letter in 'Hello':
    print(letter)

