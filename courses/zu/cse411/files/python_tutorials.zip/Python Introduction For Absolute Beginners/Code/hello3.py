message = 'Hello, world!'
print(message)