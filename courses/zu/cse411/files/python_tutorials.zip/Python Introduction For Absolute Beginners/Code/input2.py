number = input('N? ')
print(number + 1)

