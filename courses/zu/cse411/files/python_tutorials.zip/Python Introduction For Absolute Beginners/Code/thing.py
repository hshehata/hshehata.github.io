print('A')
exit()
print('B')

