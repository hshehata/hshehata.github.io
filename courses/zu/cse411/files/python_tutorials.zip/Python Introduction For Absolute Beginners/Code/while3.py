number = 1

while number > 1024 :
    print(number)
    number *=2

