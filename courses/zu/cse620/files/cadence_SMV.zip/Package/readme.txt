Installation steps:
1. Run the SMV setup file (smv_latest.exe).
2. Copy the SMV startup batch file (smv_gui.bat) to anywhere you like on your hard disk.
3. If needed, adjust the two paths mentioned in the batch file (smv_gui.bat) to point to the SMV installation folder.
4. Double-click the SMV startup batch file (smv_gui.bat) to launch the SMV GUI.